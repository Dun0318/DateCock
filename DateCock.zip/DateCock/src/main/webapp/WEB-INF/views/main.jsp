<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>

</head>
<body>
<center>
	<img src="./image/do2.gif" width="350px" height="300px">
</center>
</body>
</html>


