<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
    <c:set var="notop" value="true" />
<!DOCTYPE html>

<html>
<head>
<style type="text/css">
.userEL18853582 {
 position: relative;
}
.userEL18853582.carousel {
 height: 700px;
 min-height: 100%;
}
.userEL18853582.carousel-fade .fill {
 width: 100%;
 height: 700px;
 min-height: 100%;
 background-size: cover;
 background-position: center center;
}
.userEL18853582 .cl_caption {
 font-weight: normal;
 text-align: center;
 margin-top: 0;
 margin-bottom: 0px;
}
.userEL18853582 .carousel-indicators {
 display: none;
}
.userEL18853582.carousel .item {
 height: 100%;
 background-color: #000;
}
.userEL18853582.carousel-fade .carousel-inner .item {
 opacity: 0;
 -webkit-transition-property: opacity;
 -moz-transition-property: opacity;
 -o-transition-property: opacity;
 transition-property: opacity;
}
.userEL18853582.carousel-fade .carousel-inner .active {
 opacity: 1;
}
.userEL18853582.carousel-fade .carousel-inner .active.left,
.userEL18853582.carousel-fade .carousel-inner .active.right {
 left: 0;
 opacity: 0;
 z-index: 1;
}
.userEL18853582.carousel-fade .carousel-inner .next.left,
.userEL18853582.carousel-fade .carousel-inner .prev.right {
 opacity: 1;
}
.userEL18853582.carousel-fade, 
.userEL18853582.carousel-fade .carousel-inner, 
.userEL18853582.carousel-fade .items {
 height: 100%;
}
.userEL18853582 .userEL18853582-bg1 {
 background-image: url(./image/do.gif);
}
.userEL18853582 .userEL18853582-bg2 {
 background-image: url(./image/do2.gif);
}
.userEL18853582 .userEL18853582-bg3 {
 background-image: url(./image/flog2.gif);
}
.userEL18853582 .bg-box {
 position: absolute;
 top: 0;
 left: 0;
 right: 0;
 bottom: 0;
 width: 100%;
 height: 100%;
 background-color: #000;
 opacity: 0.3;
}
.userEL18853582.carousel-fade .bigHeader {
 position: absolute;
 left: 50%;
 top: 50%;
 -o-transform: translate(-50%, -50%);
 -webkit-transform: translate(-50%, -50%);
 -ms-transform: translate(-50%, -50%);
 -moz-transform: translate(-50%, -50%);
 transform: translate(-50%, -50%);
 display: inline-block;
 width: 80%;
 text-align: center;
}
.userEL18853582 h1.head_title {
}
.userEL18853582 div.text {
}
.userEL18853582 .carousel-control.left,
.userEL18853582 .carousel-control.right {
 background: none;
}
@media only screen and (max-width:991px) {
 .userEL18853582.carousel {
  height: 600px;
 }
}
@media only screen and (max-width:767px) {
 .userEL18853582.carousel {
  height: 540px;
 }
}
@media only screen and (max-width: 480px) {
 .userEL18853582.carousel {
  height: 450px;
 }
}
</style>
</head>
<body>
<a href = "main">홈으로</a>
<div id="userEL18853582-carousel" data-ride="carousel" data-case="slideshow8" data-interval="2000" class="userEL18853582 carousel slide carousel-fade">

    <ol class="carousel-indicators" data-nav="true">
        <li data-target="#userEL18853582-carousel" data-slide-to="0" class="active"></li>
        <li data-target="#userEL18853582-carousel" data-slide-to="1" class=""></li>
        <li data-target="#userEL18853582-carousel" data-slide-to="2" class=""></li>
    </ol>

    <!-- Carousel items -->
    <div class="carousel-inner" data-loop="true">
        <div class="item active">
            <div class="fill userEL18853582-bg1" data-attach="true" data-target=".userEL18853582-bg1"></div>
            <div class="bg-box" data-selector=".bg-box" data-obackground="true" data-title="개 까지 가능합니다"></div>
            <div class="bigHeader slideUp">
                <div class="cl_caption" data-selector=".cl_caption" data-edit="true"><div style="text-align: center; line-height: 1;"><span style="font-family: Pretendard; color: rgb(255, 255, 255);" class="fsize16"><u>PREMIUM DELICIOUS KOREA FOOD</u></span></div><div style="text-align: center;"><span style="font-family: Pretendard; color: rgb(255, 255, 255);" class="fsize16"><u>​</u></span><br></div><div style="text-align: center;"><span style="font-family: 'Gmarket Sans'; color: rgb(255, 255, 255); letter-spacing: -1px;" class="fsize48"><span style="font-weight: 400;">신선한 재료와 맛을 더한</span></span></div><div style="text-align: center;"><span style="font-family: 'Gmarket Sans'; color: rgb(255, 255, 255); letter-spacing: -1px;" class="fsize48"><span style="font-weight: 700;">다정김밥 신메뉴 3종 출시</span></span></div></div>
            </div>
        </div>
        
        
    
    <!-- Carousel nav -->
    <a class="carousel-control left" href="#userEL18853582-carousel" data-slide="prev"></a>
    <a class="carousel-control right" href="#userEL18853582-carousel" data-slide="next"></a>

</div>

</body>
</html>


