package com.mbc.datecock;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class HomeController {
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {
		 model.addAttribute("notop", true); // �̷��� �Ѱ��ֱ�
		return "servemain";
		
		
	}
	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String main() {
	
		return "main";
		
		
	}
	
}
